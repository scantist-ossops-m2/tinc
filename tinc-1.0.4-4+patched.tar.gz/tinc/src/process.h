/*
    process.h -- header file for process.c
    Copyright (C) 1999-2005 Ivo Timmermans <ivo@tinc-vpn.org>,
                  2000-2005 Guus Sliepen <guus@tinc-vpn.org>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    $Id$
*/

#ifndef __TINC_PROCESS_H__
#define __TINC_PROCESS_H__

extern bool do_detach;
extern bool sighup;
extern bool sigalrm;

extern void setup_signals(void);
extern bool execute_script(const char *, char **);
extern bool detach(void);
extern bool kill_other(int);

#endif							/* __TINC_PROCESS_H__ */
